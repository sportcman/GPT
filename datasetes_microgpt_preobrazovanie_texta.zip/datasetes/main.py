import re

# Открываем файл с данными и читаем его содержимое
with open("C:\\datasetes\\data.txt", "r", encoding="utf-8") as file:
    data = file.read()

# Разделяем текст на предложения с помощью регулярного выражения
sentences = re.split(r'(?<=[.!?])\s', data)

# Формируем строку с предложениями в нужном формате
formatted_sentence = ', '.join(['"' + sentence + '"' for sentence in sentences])

# Открываем файл для записи предложений
with open("C:\\datasetes\\sentences.txt", "w", encoding="utf-8") as file:
    # Записываем все предложения в одну строку
    file.write(formatted_sentence)
