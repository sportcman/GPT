import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import subprocess

class GPT2Generator:
    def __init__(self, model_path):
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)
        self.model = GPT2LMHeadModel.from_pretrained(model_path)

    def generate_text(self, input_text, temperature_value, length_value, num_results, no_repeat_ngram_size):
        input_ids = self.tokenizer.encode(input_text, return_tensors='pt')
        attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device=input_ids.device)

        outputs = self.model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=length_value,
            num_return_sequences=num_results,
            no_repeat_ngram_size=no_repeat_ngram_size,
            repetition_penalty=1.5,
            temperature=temperature_value,
            do_sample=True
        )

        result_text = ""
        for i, output in enumerate(outputs):
            generated_text = self.tokenizer.decode(output, skip_special_tokens=True)
            result_text += f"Результат {i+1}:\n{generated_text}\n\n"

        return result_text

gpt2_generator = GPT2Generator("C:/gpt/model")
temperature_value = 0.8
length_value = 100
num_results = 1
ngram_value = 2

def generate_text():
    input_text = input("Введите текст: ")
    result_text = gpt2_generator.generate_text(input_text, temperature_value, length_value, num_results, ngram_value)
    print(result_text)

def train_model():
    subprocess.Popen("start cmd /k python train.py", cwd="C:/gpt/", shell=True)

if __name__ == "__main__":
    while True:
        user_input = input("Выберите действие (1 - сгенерировать текст, 2 - обучение, 3 - выход): ")
        if user_input == "1":
            generate_text()
        elif user_input == "2":
            train_model()
        elif user_input == "3":
            break
        else:
            print("Некорректный ввод. Попробуйте снова.")
