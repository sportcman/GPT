from transformers import GPT2LMHeadModel, GPT2Tokenizer, TextDataset, DataCollatorForLanguageModeling, Trainer, TrainingArguments

dataset_path = "C:/gpt/dataset.txt"
model_path = "C:/gpt/model"
num_epochs = 10
batch_size = 4

tokenizer = GPT2Tokenizer.from_pretrained(model_path)
model = GPT2LMHeadModel.from_pretrained(model_path)

dataset = TextDataset(
    tokenizer=tokenizer,
    file_path=dataset_path,
    block_size=128
)

data_collator = DataCollatorForLanguageModeling(
    tokenizer=tokenizer,
    mlm=False
)

training_args = TrainingArguments(
    output_dir=model_path,
    overwrite_output_dir=True,
    num_train_epochs=1,
    per_device_train_batch_size=4,
    save_total_limit=1,
)

trainer = Trainer(
    model=model,
    args=training_args,
    data_collator=data_collator,
    train_dataset=dataset,
)

def train_model():
    trainer.train()
    model.save_pretrained(model_path)
    tokenizer.save_pretrained(model_path)

train_model()
