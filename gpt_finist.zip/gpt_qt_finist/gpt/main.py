import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QTextEdit, QVBoxLayout, QHBoxLayout, QSlider, QSpinBox, QFileDialog, QInputDialog
from PyQt5.QtCore import Qt
from transformers import GPT2LMHeadModel, GPT2Tokenizer, TextDataset, DataCollatorForLanguageModeling, Trainer, TrainingArguments
import torch

class GPT2Generator:
    def __init__(self, model_path):
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)
        self.model = GPT2LMHeadModel.from_pretrained(model_path)

    def generate_text(self, input_text, temperature_value, length_value, num_results, no_repeat_ngram_size):
        input_ids = self.tokenizer.encode(input_text, return_tensors='pt')
        attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device=input_ids.device)

        outputs = self.model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=length_value,
            num_return_sequences=num_results,
            no_repeat_ngram_size=no_repeat_ngram_size,
            repetition_penalty=1.5,
            temperature=temperature_value,
            do_sample=True
        )

        result_text = ""
        for i, output in enumerate(outputs):
            generated_text = self.tokenizer.decode(output, skip_special_tokens=True)
            result_text += f"Результат {i+1}:\n{generated_text}\n\n"

        return result_text

class GPT2App(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

        self.model_path = "C:/gpt/model"
        self.num_epochs = 1  
        self.temperature_value = 0.1 

    def initUI(self):
        self.setWindowTitle('Генератор ответов.')
        self.resize(800, 800) 

        self.input_label = QLabel('Введите вопрос:')
        self.input_text = QLineEdit()

        self.temperature_label = QLabel('Температура от 0.1 до 10.0:')
        self.temperature_slider = QSlider(Qt.Horizontal)
        self.temperature_slider.setMinimum(1)
        self.temperature_slider.setMaximum(100)
        self.temperature_slider.setValue(1)
        self.temperature_slider.setTickPosition(QSlider.TicksBelow)
        self.temperature_slider.setTickInterval(10)
        self.temperature_display = QLabel('0.01')

        self.length_label = QLabel('Длина текста до 3000 символов:')
        self.length_spinbox = QSpinBox()
        self.length_spinbox.setMinimum(10)
        self.length_spinbox.setMaximum(3000)
        self.length_spinbox.setValue(100)

        self.num_results_label = QLabel('Количество вариантов от 1 до 100:')
        self.num_results_spinbox = QSpinBox()
        self.num_results_spinbox.setMinimum(1)
        self.num_results_spinbox.setMaximum(100)
        self.num_results_spinbox.setValue(1)

        self.generate_button = QPushButton('Сгенерировать ответ.')
        self.generate_button.clicked.connect(self.generateText)

        self.select_file_button = QPushButton('Начать обучение?')
        self.select_file_button.clicked.connect(self.selectDatasetFile)

        vbox = QVBoxLayout()
        vbox.addWidget(self.input_label)
        vbox.addWidget(self.input_text)
        vbox.addWidget(self.temperature_label)
        vbox.addWidget(self.temperature_slider)
        vbox.addWidget(self.temperature_display)
        vbox.addWidget(self.length_label)
        vbox.addWidget(self.length_spinbox)
        vbox.addWidget(self.num_results_label)
        vbox.addWidget(self.num_results_spinbox)
        vbox.addWidget(self.generate_button)
        vbox.addWidget(self.select_file_button)

        self.result_text = QTextEdit()
        vbox.addWidget(self.result_text)

        self.setLayout(vbox)
        self.show()

        self.temperature_slider.valueChanged.connect(self.updateTemperatureDisplay)

    def generateText(self):
        input_text = self.input_text.text()
        length_value = self.length_spinbox.value()
        num_results = self.num_results_spinbox.value()
        ngram_value = 2

        gpt2_generator = GPT2Generator(self.model_path)
        result_text = gpt2_generator.generate_text(
            input_text, self.temperature_value, length_value, num_results, ngram_value)
        self.result_text.setText(result_text)

    def selectDatasetFile(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Выбрать файл для обучения', '', 'Text files (*.txt)')
        if filename:
            self.dataset_path = filename
            self.trainModel()

    def trainModel(self):
        num_epochs, ok = QInputDialog.getInt(
            self, 'Количество эпох', 'Введите количество эпох:', value=self.num_epochs)
        if ok:
            self.num_epochs = num_epochs 
            self.trainModelWithSelectedEpochs()

    def trainModelWithSelectedEpochs(self):
        batch_size = 4

        tokenizer = GPT2Tokenizer.from_pretrained(self.model_path)
        model = GPT2LMHeadModel.from_pretrained(self.model_path)

        dataset = TextDataset(
            tokenizer=tokenizer,
            file_path=self.dataset_path,
            block_size=128
        )

        data_collator = DataCollatorForLanguageModeling(
            tokenizer=tokenizer,
            mlm=False
        )

        training_args = TrainingArguments(
            output_dir=self.model_path,
            overwrite_output_dir=True,
            num_train_epochs=self.num_epochs, 
            per_device_train_batch_size=batch_size,
            save_total_limit=1,
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            data_collator=data_collator,
            train_dataset=dataset,
        )

        trainer.train()
        model.save_pretrained(self.model_path)
        tokenizer.save_pretrained(self.model_path)

    def updateTemperatureDisplay(self, value):
        self.temperature_value = value / 10.0
        self.temperature_display.setText(str(self.temperature_value))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = GPT2App()
    sys.exit(app.exec_())
