import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QMessageBox, QLabel
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtCore import QUrl, Qt
import subprocess

class MyApplication(QWidget):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        self.setWindowTitle('GptYulia')
        self.setGeometry(300, 300, 300, 200)

        layout = QVBoxLayout()

        h_layout = QHBoxLayout()
        btn1 = self.create_button('Запустить основной интерфейс', self.run_main_script)
        btn2 = self.create_button('Запустить web интерфейс.', self.run_app_script)
        h_layout.addWidget(btn1)
        h_layout.addWidget(btn2)
        layout.addLayout(h_layout)

        link_label = QLabel()
        link_label.setText('<a href="http://127.0.0.1:5000">Web интерфейс</a>')
        link_label.setOpenExternalLinks(True)
        link_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(link_label)

        self.setLayout(layout)

    def create_button(self, text, on_click):
        btn = QPushButton(text, self)
        btn.clicked.connect(on_click)
        return btn

    def run_main_script(self):
        self.run_script('C:/gpt/main.py', 'Основной интерфейс запущен.')

    def run_app_script(self):
        self.run_script('C:/gpt/app.py', 'Web интерфейс запущен.')

    def run_script(self, script_path, message):
        subprocess.Popen(['python', script_path])
        self.show_message(message)

    def show_message(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(message)
        msg.setWindowTitle("Информация")
        msg.exec_()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyApplication()
    ex.show()
    sys.exit(app.exec_())
