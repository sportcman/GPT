from transformers import GPT2Tokenizer, TextDataset, DataCollatorForLanguageModeling, Trainer, TrainingArguments, GPT2LMHeadModel
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--num_epochs', type=int, default=1)  # добавляем аргумент для количества эпох
    parser.add_argument('--dataset_path', type=str, default="C:/gpt/dataset.txt")  # добавляем аргумент для пути к датасету
    args = parser.parse_args()

    dataset_path = args.dataset_path
    model_path = "C:/gpt/model"
    batch_size = 4

    tokenizer = GPT2Tokenizer.from_pretrained(model_path)
    model = GPT2LMHeadModel.from_pretrained(model_path)

    dataset = TextDataset(
        tokenizer=tokenizer,
        file_path=dataset_path,
        block_size=128
    )

    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False
    )

    training_args = TrainingArguments(
        output_dir=model_path,
        overwrite_output_dir=True,
        num_train_epochs=args.num_epochs,  # используем переданное количество эпох
        per_device_train_batch_size=batch_size,
        save_total_limit=1,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        data_collator=data_collator,
        train_dataset=dataset,
    )

    trainer.train()
    model.save_pretrained(model_path)
    tokenizer.save_pretrained(model_path)

if __name__ == '__main__':
    main()
