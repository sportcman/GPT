import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import torch
from transformers import GPT2LMHeadModel, GPT2Tokenizer
import pyperclip
import subprocess
import win32gui, win32con

hwnd = win32gui.GetForegroundWindow()
win32gui.ShowWindow(hwnd, win32con.SW_HIDE)

class GPT2Generator:
    def __init__(self, model_path):
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)
        self.model = GPT2LMHeadModel.from_pretrained(model_path)

    def generate_text(self, input_text, temperature_value, length_value, num_results, no_repeat_ngram_size):
        input_ids = self.tokenizer.encode(input_text, return_tensors='pt')
        attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device=input_ids.device)

        outputs = self.model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            max_length=length_value,
            num_return_sequences=num_results,
            no_repeat_ngram_size=no_repeat_ngram_size,
            repetition_penalty=1.5,
            temperature=temperature_value,
            do_sample=True
        )

        result_text = ""
        for i, output in enumerate(outputs):
            generated_text = self.tokenizer.decode(output, skip_special_tokens=True)
            result_text += f"Результат {i+1}:\n{generated_text}\n\n"

        return result_text

class App:
    def __init__(self):
        self.gpt2_generator = GPT2Generator("C:/gpt/model")
        self.temperature_value = 0.8
        self.length_value = 100
        self.num_results = 1
        self.ngram_value = 2

        self.root = tk.Tk()
        self.root.title("Генератор текста на основе GPT-2")
        self.root.geometry("1000x800")

        self.input_label = tk.Label(self.root, text="Введите текст:", font=('Arial', 14))
        self.input_label.pack(side="top", padx=10, pady=10, anchor="w")

        self.input_entry = tk.Entry(self.root, width=80, font=('Arial', 12))
        self.input_entry.pack(side="top", padx=10, pady=10)

        self.button_frame = tk.Frame(self.root)
        self.button_frame.pack(side="bottom", padx=10, pady=10, anchor="se")

        self.generate_button = tk.Button(self.button_frame, text="Генерировать", command=self.generate_text)
        self.generate_button.pack(side="left", padx=5)

        self.train_button = tk.Button(self.button_frame, text="Обучение", command=self.train_model)
        self.train_button.pack(side="left", padx=5)

        self.clear_button = tk.Button(self.button_frame, text="Очистить", command=self.clear_text)
        self.clear_button.pack(side="left", padx=5)

        self.copy_button = tk.Button(self.button_frame, text="Копировать", command=self.copy_text)
        self.copy_button.pack(side="left", padx=5)

        self.save_button = tk.Button(self.button_frame, text="Сохранить", command=self.save_text)
        self.save_button.pack(side="left", padx=5)

        self.output_text = tk.Text(self.root, font=('Arial', 12), height=10)
        self.output_text.pack(side="bottom", padx=10, pady=10, fill="both", expand=True)

        self.scrollbar = tk.Scrollbar(self.root, command=self.output_text.yview)
        self.scrollbar.pack(side="right", fill="y")

        self.output_text.config(yscrollcommand=self.scrollbar.set)

        self.temperature_label = tk.Label(self.root, text="Температура:", font=('Arial', 10))
        self.temperature_label.pack(side="top", padx=10, pady=5, anchor="w")

        self.temperature_slider = tk.Scale(
            self.root,
            from_=0.1,
            to=1.0,
            resolution=0.1,
            orient="horizontal",
            length=200,
            command=self.update_temperature
        )
        self.temperature_slider.set(self.temperature_value)
        self.temperature_slider.pack(side="top", padx=10, pady=10, anchor="w")

        self.length_label = tk.Label(self.root, text="Длина текста:", font=('Arial', 10))
        self.length_label.pack(side="top", padx=10, pady=5, anchor="w")

        self.length_slider = tk.Scale(
            self.root,
            from_=50,
            to=2000,
            resolution=1,
            orient="horizontal",
            length=200,
            command=self.update_length
        )
        self.length_slider.set(self.length_value)
        self.length_slider.pack(side="top", padx=10, pady=10, anchor="w")

        self.num_results_label = tk.Label(self.root, text="Количество результатов:", font=('Arial', 10))
        self.num_results_label.pack(side="top", padx=10, pady=5, anchor="w")

        self.num_results_slider = tk.Scale(
            self.root,
            from_=1,
            to=5,
            orient="horizontal",
            length=200,
            command=self.update_num_results
        )
        self.num_results_slider.set(self.num_results)
        self.num_results_slider.pack(side="top", padx=10, pady=10, anchor="w")

        self.ngram_label = tk.Label(self.root, text="Количество повторов n-грамм:", font=('Arial', 10))
        self.ngram_label.pack(side="top", padx=10, pady=5, anchor="w")

        self.ngram_slider = tk.Scale(
            self.root,
            from_=1,
            to=5,
            orient="horizontal",
            length=200,
            command=self.update_ngram
        )
        self.ngram_slider.set(self.ngram_value)
        self.ngram_slider.pack(side="top", padx=10, pady=10, anchor="w")

        self.root.mainloop()      

    def generate_text(self):
        input_text = self.input_entry.get()
        result_text = self.gpt2_generator.generate_text(input_text, self.temperature_value, self.length_value,
                                                       self.num_results, self.ngram_value)
        self.output_text.delete('1.0', tk.END)
        self.output_text.insert(tk.END, result_text)

    def clear_text(self):
        self.input_entry.delete(0, tk.END)
        self.output_text.delete('1.0', tk.END)

    def copy_text(self):
        generated_text = self.output_text.get('1.0', tk.END)
        pyperclip.copy(generated_text)
        messagebox.showinfo("Скопировано", "Текст скопирован в буфер обмена.")

    def save_text(self):
        generated_text = self.output_text.get('1.0', tk.END)
        file_path = filedialog.asksaveasfilename(defaultextension=".txt")
        if file_path:
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(generated_text)
                messagebox.showinfo("Сохранено", "Текст сохранен в файл.")
        else:
            pass

    def update_temperature(self, value):
        self.temperature_value = float(value)

    def update_length(self, value):
        self.length_value = int(value)

    def update_num_results(self, value):
        self.num_results = int(value)

    def update_ngram(self, value):
        self.ngram_value = int(value)

    def train_model(self):
        subprocess.Popen("start cmd /k python train.py", cwd="C:/gpt/", shell=True)

if __name__ == "__main__":
    App()
