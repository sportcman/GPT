import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk
from transformers import GPT2LMHeadModel, GPT2Tokenizer, TextDataset, DataCollatorForLanguageModeling, Trainer, TrainingArguments
import win32gui, win32con

hwnd = win32gui.GetForegroundWindow()
win32gui.ShowWindow(hwnd, win32con.SW_HIDE)

class GPT2TrainerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("GPT-2 Trainer")
        self.root.geometry("200x170")

        self.dataset_path = None
        self.model_path = "C:/gpt/model"
        self.num_epochs = 10
        self.batch_size = 4

        self.create_widgets()

    def create_widgets(self):
        # Dataset path selection button
        self.dataset_button = tk.Button(self.root, text="Выбрать датасет", command=self.choose_dataset)
        self.dataset_button.pack()

        # Epochs selection scale
        self.epochs_label = tk.Label(self.root, text="Количество эпох обучения:")
        self.epochs_label.pack()
        self.epochs_scale = tk.Scale(self.root, from_=1, to=20, orient=tk.HORIZONTAL)
        self.epochs_scale.set(10)
        self.epochs_scale.pack()

        # Batch size selection
        self.batch_label = tk.Label(self.root, text="Размер пакета (batch size):")
        self.batch_label.pack()
        self.batch_combobox = ttk.Combobox(self.root, values=(2, 4, 8, 16, 32))
        self.batch_combobox.set(4)
        self.batch_combobox.pack()

        # Train button
        self.train_button = tk.Button(self.root, text="Обучить модель GPT-2", command=self.start_training)
        self.train_button.pack()

    def choose_dataset(self):
        self.dataset_path = filedialog.askopenfilename()
        if self.dataset_path:
            messagebox.showinfo("Информация", "Датасет успешно выбран")

    def start_training(self):
        if self.dataset_path is None:
            messagebox.showerror("Ошибка", "Пожалуйста, выберите путь к датасету")
            return

        self.num_epochs = self.epochs_scale.get()
        self.batch_size = int(self.batch_combobox.get())

        tokenizer = GPT2Tokenizer.from_pretrained(self.model_path)
        model = GPT2LMHeadModel.from_pretrained(self.model_path)

        dataset = TextDataset(
            tokenizer=tokenizer,
            file_path=self.dataset_path,
            block_size=128
        )

        data_collator = DataCollatorForLanguageModeling(
            tokenizer=tokenizer,
            mlm=False
        )

        training_args = TrainingArguments(
            output_dir=self.model_path,
            overwrite_output_dir=True,
            num_train_epochs=self.num_epochs,
            per_device_train_batch_size=self.batch_size,
            save_total_limit=1,
        )

        trainer = Trainer(
            model=model,
            args=training_args,
            data_collator=data_collator,
            train_dataset=dataset,
        )

        def train_model():
            trainer.train()
            model.save_pretrained(self.model_path)
            tokenizer.save_pretrained(self.model_path)
            messagebox.showinfo("Информация", "Обучение модели завершено успешно")

        # 在主线程中训练模型
        train_model()

if __name__ == "__main__":
    root = tk.Tk()
    app = GPT2TrainerGUI(root)
    root.mainloop()
