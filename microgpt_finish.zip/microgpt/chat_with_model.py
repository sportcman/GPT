import tkinter as tk
import os
import numpy as np
import pickle
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

model_dir = "C:\\microgpt\\model"

tokenizer_file = os.path.join(model_dir, 'tokenizer.pkl')
model_file = os.path.join(model_dir, 'my_language_model.h5')

# Загрузка токенизатора
with open(tokenizer_file, 'rb') as f:
    tokenizer = pickle.load(f)

# Загрузка модели
model = load_model(model_file)

def generate_text():
    seed_text = seed_text_entry.get()
    next_words = int(next_words_entry.get())
    
    generated_text = seed_text
    
    for _ in range(next_words):
        encoded = tokenizer.texts_to_sequences([seed_text])[0]
        encoded = pad_sequences([encoded], maxlen=model.input_shape[1], padding='post')
        predicted = model.predict(encoded, verbose=0)
        predicted_class = np.argmax(predicted)
        output_word = ""
        for word, index in tokenizer.word_index.items():
            if index == predicted_class:
                output_word = word
                break
        seed_text += " " + output_word
        generated_text += " " + output_word
    
    generated_text_text.delete(1.0, tk.END)  # Очистить предыдущий текст
    generated_text_text.insert(tk.END, generated_text)

# Создание GUI интерфейса
window = tk.Tk()
window.title("Генерация текста")
window.geometry("400x250")

seed_text_label = tk.Label(window, text="Введите начальный текст:")
seed_text_label.pack(pady=5)

seed_text_entry = tk.Entry(window)
seed_text_entry.pack(pady=5)

next_words_label = tk.Label(window, text="Введите количество слов для генерации:")
next_words_label.pack(pady=5)

next_words_entry = tk.Entry(window)
next_words_entry.pack(pady=5)

generate_button = tk.Button(window, text="Сгенерировать", command=generate_text)
generate_button.pack(pady=5)

generated_text_frame = tk.Frame(window)
generated_text_frame.pack(pady=5)

generated_text_scrollbar = tk.Scrollbar(generated_text_frame)
generated_text_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

generated_text_text = tk.Text(generated_text_frame, wrap="word")
generated_text_text.pack(side=tk.LEFT, fill=tk.BOTH)

generated_text_scrollbar.config(command=generated_text_text.yview)
generated_text_text.config(yscrollcommand=generated_text_scrollbar.set)

window.mainloop()
