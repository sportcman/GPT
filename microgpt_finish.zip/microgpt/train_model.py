import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from tkinter.ttk import Progressbar
import os
import numpy as np
import pickle
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Embedding, LSTM, Dense, Bidirectional, Dropout
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

model_dir = "C:\\microgpt\\model"
dataset_file = "C:\\microgpt\\dataset.txt"

# Загрузка или создание токенизатора
tokenizer_file = os.path.join(model_dir, 'tokenizer.pkl')

if os.path.exists(tokenizer_file):
    with open(tokenizer_file, 'rb') as f:
        tokenizer = pickle.load(f)
else:
    tokenizer = Tokenizer()

def prepare_data():
    global tokenizer
    if os.path.exists(dataset_file):
        with open(dataset_file, 'r', encoding='utf-8') as f:
            texts = f.readlines()
    else:
        texts = ["Привет, как дела?", "Привет, как жизнь?", "Привет, как ты?"]

    tokenizer.fit_on_texts(texts)

    # Сохранение токенизатора
    with open(tokenizer_file, 'wb') as f:
        pickle.dump(tokenizer, f)

    vocab_size = len(tokenizer.word_index) + 1

    sequences = tokenizer.texts_to_sequences(texts)
    max_sequence_len = max([len(sequence) for sequence in sequences])
    padded_sequences = pad_sequences(sequences, maxlen=max_sequence_len, padding='post')

    X = padded_sequences[:, :-1]
    y = padded_sequences[:, -1]

    return X, y, max_sequence_len, vocab_size

def create_model(vocab_size, max_sequence_len):
    model_file = os.path.join(model_dir, 'my_language_model.h5')

    if os.path.exists(model_file):
        model = load_model(model_file)
    else:
        model = Sequential()
        model.add(Embedding(vocab_size, 5, input_length=max_sequence_len-1))
        model.add(Bidirectional(LSTM(10, return_sequences=True)))
        model.add(Dropout(0.1))
        model.add(Bidirectional(LSTM(5)))
        model.add(Dense(vocab_size, activation='softmax'))

        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    return model

def train_model():
    X, y, max_sequence_len, vocab_size = prepare_data()
    model = create_model(vocab_size, max_sequence_len)

    progress_bar = Progressbar(window, orient="horizontal", length=300, mode="determinate")
    progress_bar.pack()

    def update_progress(epoch, epochs):
        progress = epoch / epochs * 100
        progress_bar["value"] = progress
        window.update_idletasks()

    epochs =1
    for epoch in range(epochs):
        model.fit(X, y, epochs=1, verbose=0)
        update_progress(epoch + 1, epochs)

    # Сохранение модели
    model_file = os.path.join(model_dir, 'my_language_model.h5')
    model.save(model_file)

def browse_button():
    global dataset_file
    dataset_file = filedialog.askopenfilename()

def train_button():
    try:
        train_model()
        messagebox.showinfo("Информация", "Модель успешно обучена и сохранена.")
    except:
        messagebox.showerror("Ошибка", "Произошла ошибка при обучении модели.")

# Создание GUI интерфейса
window = tk.Tk()
window.title("Обучение модели")
window.geometry("400x250")

browse_label = tk.Label(window, text="Выберите файл с данными:")
browse_label.pack(pady=5)

browse_button = tk.Button(window, text="Обзор", command=browse_button)
browse_button.pack(pady=5)

train_button = tk.Button(window, text="Обучить модель", command=train_button)
train_button.pack(pady=5)

window.mainloop()
