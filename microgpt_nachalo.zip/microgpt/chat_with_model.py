import os
import numpy as np
import pickle
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

model_dir = "C:\\microgpt\\model"

tokenizer_file = os.path.join(model_dir, 'tokenizer.pkl')
model_file = os.path.join(model_dir, 'my_language_model.h5')

# Загрузка токенизатора
with open(tokenizer_file, 'rb') as f:
    tokenizer = pickle.load(f)

# Загрузка модели
model = load_model(model_file)

# Генерация текста с использованием загруженной модели и токенизатора
seed_text = "0+1="
next_words = 5

for _ in range(next_words):
    encoded = tokenizer.texts_to_sequences([seed_text])[0]
    encoded = pad_sequences([encoded], maxlen=model.input_shape[1], padding='post')
    predicted = model.predict(encoded, verbose=0)
    predicted_class = np.argmax(predicted)
    output_word = ""
    for word, index in tokenizer.word_index.items():
        if index == predicted_class:
            output_word = word
            break
    seed_text += " " + output_word

print(seed_text)
