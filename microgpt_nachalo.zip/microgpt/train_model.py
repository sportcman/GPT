import os
import numpy as np
import pickle
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Embedding, LSTM, Dense, Bidirectional, Dropout
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

model_dir = "C:\\microgpt\\model"
dataset_file = "C:\\microgpt\\dataset.txt"

# Проверяем, существует ли папка для модели, и создаем ее при необходимости
if not os.path.exists(model_dir):
    os.makedirs(model_dir)

tokenizer_file = os.path.join(model_dir, 'tokenizer.pkl')
model_file = os.path.join(model_dir, 'my_language_model.h5')

# Подготовка данных
if os.path.exists(dataset_file):
    with open(dataset_file, 'r', encoding='utf-8') as f:
        texts = f.readlines()
else:
    texts = ["Привет, как дела?", "Привет, как жизнь?", "Привет, как ты?"]

# Загрузка или создание токенизатора
if os.path.exists(tokenizer_file):
    with open(tokenizer_file, 'rb') as f:
        tokenizer = pickle.load(f)
else:
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(texts)

    # Сохранение токенизатора
    with open(tokenizer_file, 'wb') as f:
        pickle.dump(tokenizer, f)
vocab_size = len(tokenizer.word_index) + 1

sequences = tokenizer.texts_to_sequences(texts)
max_sequence_len = max([len(sequence) for sequence in sequences])
padded_sequences = pad_sequences(sequences, maxlen=max_sequence_len, padding='post')

X = padded_sequences[:, :-1]
y = padded_sequences[:, -1]

# Загрузка или создание модели
if os.path.exists(model_file):
    model = load_model(model_file)
else:
    model = Sequential()
    model.add(Embedding(vocab_size, 10, input_length=max_sequence_len-1))
    model.add(Bidirectional(LSTM(15, return_sequences=True)))
    model.add(Dropout(0.2))
    model.add(Bidirectional(LSTM(10)))
    model.add(Dense(vocab_size, activation='softmax'))

    model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

# Обучение модели
model.fit(X, y, epochs=1, verbose=1)

# Сохранение модели
model.save(model_file)
