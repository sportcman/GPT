import json
import os
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt


class DatasetConverter(QWidget):
    def __init__(self):
        super().__init__()

        self.init_ui()

    def init_ui(self):
        # Основное окно
        self.setWindowTitle("Конвертер датасета GPT в responses.py")
        self.setGeometry(100, 100, 400, 200)

        layout = QVBoxLayout()

        # Заголовок
        self.label = QLabel("Выберите файл для конвертации:")
        layout.addWidget(self.label)

        # Кнопка для выбора файла датасета
        self.btn_open = QPushButton("Выбрать файл JSON")
        self.btn_open.clicked.connect(self.open_file)
        layout.addWidget(self.btn_open)

        # Кнопка для выбора пути сохранения преобразованного файла
        self.btn_save = QPushButton("Сохранить как...")
        self.btn_save.clicked.connect(self.save_file)
        self.btn_save.setEnabled(False)
        layout.addWidget(self.btn_save)

        self.setLayout(layout)

        self.dataset = None  # Данные из файла будут сохранены здесь

    def open_file(self):
        # Диалог для выбора JSON файла
        file_path, _ = QFileDialog.getOpenFileName(self, "Выбрать файл JSON", "", "JSON Files (*.json)")
        
        if file_path:
            self.label.setText(f"Выбран файл: {file_path}")
            try:
                # Загрузка данных из JSON файла
                with open(file_path, 'r', encoding='utf-8') as file:
                    self.dataset = json.load(file)
                
                QMessageBox.information(self, "Успех", "Файл успешно загружен!")
                self.btn_save.setEnabled(True)
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось загрузить файл:\n{e}")

    def save_file(self):
        # Диалог для сохранения преобразованного файла
        save_path, _ = QFileDialog.getSaveFileName(self, "Сохранить как", "", "Python Files (*.py)")
        
        if save_path:
            try:
                # Преобразование и сохранение
                converted_data = self.convert_dataset_to_responses(self.dataset)
                with open(save_path, 'w', encoding='utf-8') as file:
                    file.write(converted_data)
                
                QMessageBox.information(self, "Успех", f"Файл успешно сохранён как {save_path}!")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Не удалось сохранить файл:\n{e}")

    def convert_dataset_to_responses(self, dataset):
        # Преобразуем датасет в формат responses.py
        responses = {}
        for entry in dataset:
            prompt = entry["prompt"].strip().lower()
            response = entry["response"].strip()
            responses[prompt] = response

        # Генерация текста для файла
        lines = ["responses = {"]
        for prompt, response in responses.items():
            lines.append(f'    "{prompt}": "{response}",')
        lines.append("}")

        return "\n".join(lines)


if __name__ == "__main__":
    app = QApplication([])

    window = DatasetConverter()
    window.show()

    app.exec()
