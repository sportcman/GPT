import os
from datetime import datetime, timedelta
import shutil
import json
from PyQt6.QtWidgets import QWidget, QPushButton, QVBoxLayout, QProgressBar, QTextEdit, QLabel, QFileDialog, QApplication, QSpinBox, QFormLayout, QCheckBox
from PyQt6.QtCore import QThread, pyqtSignal
from transformers import GPT2Tokenizer, GPT2LMHeadModel, AdamW
from torch.utils.data import DataLoader
import torch
from torch.optim.lr_scheduler import StepLR
import optuna
from PyQt6.QtGui import QIcon  # Импорт QIcon

# Кастомный датасет с опцией перекрытия фрагментов
class CustomTextDataset(torch.utils.data.Dataset):
    def __init__(self, tokenizer, file_path, block_size, overlap_size=0):
        self.examples = []

        with open(file_path, encoding="utf-8") as f:
            data = json.load(f)

        for item in data:
            prompt = item["prompt"]
            response = item["response"]
            full_text = f"{prompt} {response}"

            tokenized_text = tokenizer.encode(full_text, add_special_tokens=True)

            # Разбиение на фрагменты с учётом overlap_size
            step_size = block_size - overlap_size if overlap_size > 0 else block_size
            for i in range(0, len(tokenized_text), step_size):
                fragment = tokenized_text[i:i + block_size]
                if len(fragment) == block_size:
                    self.examples.append(fragment)

    def __len__(self):
        return len(self.examples)

    def __getitem__(self, i):
        return torch.tensor(self.examples[i], dtype=torch.long)

class TrainingWorker(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    training_finished = pyqtSignal()

    def __init__(self, model_path, dataset_path, device, batch_size, epochs, gradient_accumulation_steps, overlap_enabled, overlap_size, block_size):
        super().__init__()
        self.model_path = model_path
        self.dataset_path = dataset_path
        self.device = device
        self.batch_size = batch_size
        self.epochs = epochs
        self.gradient_accumulation_steps = gradient_accumulation_steps
        self.overlap_enabled = overlap_enabled
        self.overlap_size = overlap_size
        self.block_size = block_size
        self.is_running = True

    def run(self):
        try:
            # Проверяем, существует ли модель и токенизатор по указанному пути
            if not os.path.exists(self.model_path):
                self.update_log.emit(f"Модель не найдена по указанному пути: {self.model_path}")
                self.training_finished.emit()
                return

            if not os.path.exists(os.path.join(self.model_path, 'tokenizer_config.json')):
                self.update_log.emit(f"Токенизатор не найден по указанному пути: {self.model_path}")
                self.training_finished.emit()
                return

            # Инициализация токенизатора, модели и других параметров
            tokenizer = GPT2Tokenizer.from_pretrained(self.model_path)
            model = GPT2LMHeadModel.from_pretrained(self.model_path)
            model.to(self.device)

            overlap_size = self.overlap_size if self.overlap_enabled else 0
            dataset = CustomTextDataset(tokenizer, self.dataset_path, block_size=self.block_size, overlap_size=overlap_size)
            data_loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
            optimizer = AdamW(model.parameters(), lr=5e-5)
            scheduler = StepLR(optimizer, step_size=1, gamma=0.95)

            model.train()

            total_steps = len(data_loader) * self.epochs
            self.start_time = datetime.now()  # Начальное время
            accum_steps = 0

            # Основной цикл обучения
            for epoch in range(self.epochs):
                if not self.is_running:
                    break

                for i, batch in enumerate(data_loader):
                    if not self.is_running:
                        break

                    # Перенос данных на устройство и расчет потерь
                    inputs = batch.to(self.device)
                    labels = batch.to(self.device)
                    outputs = model(inputs, labels=labels, attention_mask=inputs != tokenizer.pad_token_id)
                    loss = outputs.loss
                    loss.backward()

                    # Шаг оптимизатора после накопления градиентов
                    if (i + 1) % self.gradient_accumulation_steps == 0 or (i + 1) == len(data_loader):
                        optimizer.step()
                        optimizer.zero_grad()
                        accum_steps = 0
                    else:
                        accum_steps += 1

                    # Обновление прогресса и логов
                    current_step = epoch * len(data_loader) + i + 1
                    self.update_progress.emit(int((current_step / total_steps) * 100))

                    # Рассчитываем время для лога
                    current_time = datetime.now()
                    elapsed_time = current_time - self.start_time
                    progress = current_step / total_steps
                    remaining_time = timedelta(seconds=(elapsed_time.total_seconds() / progress) - elapsed_time.total_seconds()) if progress > 0 else timedelta(seconds=0)

                    # Логирование информации
                    self.update_log.emit(
                        f"Эпоха {epoch + 1}/{self.epochs}, Партия {i + 1}/{len(data_loader)}, "
                        f"Потеря: {loss.item():.10f}, Время: {current_time.strftime('%H:%M:%S')}, "
                        f"Оставшееся время: {str(remaining_time).split('.')[0]}"
                    )

                # Шаг планировщика после каждой эпохи
                scheduler.step()
                self.update_log.emit(f"Эпоха {epoch + 1}/{self.epochs} завершена.")

            # Сохранение модели и токенизатора после завершения обучения
            if self.is_running:
                self.save_model_and_tokenizer(model, tokenizer)
                self.update_log.emit("Обучение завершено успешно.")
            else:
                self.update_log.emit("Обучение остановлено пользователем.")

            self.training_finished.emit()

        except Exception as e:
            # Обработка исключений и завершение
            self.update_log.emit(f"Произошла ошибка: {str(e)}")
            self.training_finished.emit()

    def stop_training(self):
        self.is_running = False
        tokenizer = GPT2Tokenizer.from_pretrained(self.model_path)
        model = GPT2LMHeadModel.from_pretrained(self.model_path)
        model.to(self.device)
        self.save_model_and_tokenizer(model, tokenizer)
        self.update_log.emit("Обучение было остановлено, модель сохранена.")

    def save_model_and_tokenizer(self, model, tokenizer):
        model_save_path = os.path.join(self.model_path, '')
        tokenizer_save_path = os.path.join(self.model_path, '')

        if os.path.exists(model_save_path):
            shutil.rmtree(model_save_path)
        if os.path.exists(tokenizer_save_path):
            shutil.rmtree(tokenizer_save_path)

        os.makedirs(model_save_path, exist_ok=True)
        os.makedirs(tokenizer_save_path, exist_ok=True)

        try:
            self.update_log.emit(f"Сохранение модели в {model_save_path}")
            model.save_pretrained(model_save_path)

            self.update_log.emit(f"Сохранение токенизатора в {tokenizer_save_path}")
            tokenizer.save_pretrained(tokenizer_save_path)

            self.update_log.emit("Модель и токенизатор успешно сохранены.")
        except Exception as e:
            self.update_log.emit(f"Ошибка при сохранении модели или токенизатора: {str(e)}")

    def optimize_params(self, model, data_loader):
        tokenizer = GPT2Tokenizer.from_pretrained(self.model_path)

        def objective(trial):
            lr = trial.suggest_float("lr", 1e-6, 1e-4, log=True)
            optimizer = AdamW(model.parameters(), lr=lr)
            scheduler = StepLR(optimizer, step_size=1, gamma=trial.suggest_float("gamma", 0.8, 1.0))

            model.train()
            total_loss = 0
            for i, batch in enumerate(data_loader):
                inputs = batch.to(self.device)
                labels = batch.to(self.device)

                outputs = model(inputs, labels=labels, attention_mask=inputs != tokenizer.pad_token_id)
                loss = outputs.loss

                loss.backward()
                optimizer.step()
                optimizer.zero_grad()

                total_loss += loss.item()
                if i >= 10:  # ограничим количество шагов для тестирования
                    break

            return total_loss / (i + 1)

        study = optuna.create_study(direction="minimize")
        study.optimize(objective, n_trials=5)

        # Получаем оптимизированные параметры
        best_lr = study.best_trial.params['lr']
        best_gamma = study.best_trial.params['gamma']

        optimizer = AdamW(model.parameters(), lr=best_lr)
        scheduler = StepLR(optimizer, step_size=1, gamma=best_gamma)

        return optimizer, scheduler


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.worker = None
        self.initUI()
        # Основные настройки окна
        self.setWindowTitle('Мастер тренеровок JSON prompt; response; gamma v.2')
        self.setGeometry(0, 0, 600, 400)
        self.setWindowIcon(QIcon("F:/icon/ICO/trener_gpt.ico"))

    def initUI(self):
        layout = QVBoxLayout()

        self.start_button = QPushButton('Начать обучение', self)
        self.start_button.clicked.connect(self.start_training)

        self.stop_button = QPushButton('Остановить обучение', self)
        self.stop_button.clicked.connect(self.stop_training)
        self.stop_button.setEnabled(False)

        self.progress_bar = QProgressBar(self)
        self.log_text = QTextEdit(self)
        self.log_text.setReadOnly(True)

        self.model_label = QLabel('Модель: Не выбрана', self)
        self.dataset_label = QLabel('Датасет: Не выбран', self)

        self.model_button = QPushButton('Выбрать модель', self)
        self.model_button.clicked.connect(self.select_model)

        self.dataset_button = QPushButton('Выбрать датасет', self)
        self.dataset_button.clicked.connect(self.select_dataset)

        # Поля для ввода параметров batch_size, epochs, gradient_accumulation_steps, block_size
        self.batch_size_input = QSpinBox(self)
        self.batch_size_input.setRange(1, 1024)
        self.batch_size_input.setValue(8)

        self.epochs_input = QSpinBox(self)
        self.epochs_input.setRange(1, 100)
        self.epochs_input.setValue(3)

        self.gradient_accumulation_steps_input = QSpinBox(self)
        self.gradient_accumulation_steps_input.setRange(1, 32)
        self.gradient_accumulation_steps_input.setValue(1)

        self.block_size_input = QSpinBox(self)
        self.block_size_input.setRange(32, 1024)
        self.block_size_input.setValue(512)

        self.overlap_checkbox = QCheckBox('Использовать перекрытие', self)
        self.overlap_checkbox.setChecked(False)

        form_layout = QFormLayout()
        form_layout.addRow('Batch size:', self.batch_size_input)
        form_layout.addRow('Epochs:', self.epochs_input)
        form_layout.addRow('Gradient Accumulation Steps:', self.gradient_accumulation_steps_input)
        form_layout.addRow('Block Size:', self.block_size_input)
        form_layout.addRow(self.overlap_checkbox)

        layout.addWidget(self.model_label)
        layout.addWidget(self.model_button)
        layout.addWidget(self.dataset_label)
        layout.addWidget(self.dataset_button)
        layout.addWidget(self.start_button)
        layout.addWidget(self.stop_button)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.log_text)
        layout.addLayout(form_layout)

        self.setLayout(layout)

    def select_model(self):
        model_path = QFileDialog.getExistingDirectory(self, 'Выбрать папку модели')
        if model_path:
            self.model_label.setText(f'Модель: {model_path}')

    def select_dataset(self):
        dataset_path, _ = QFileDialog.getOpenFileName(self, 'Выбрать датасет', '', 'JSON Files (*.json)')
        if dataset_path:
            self.dataset_label.setText(f'Датасет: {dataset_path}')

    def start_training(self):
        model_path = self.model_label.text().replace('Модель: ', '')
        dataset_path = self.dataset_label.text().replace('Датасет: ', '')
        batch_size = self.batch_size_input.value()
        epochs = self.epochs_input.value()
        gradient_accumulation_steps = self.gradient_accumulation_steps_input.value()
        overlap_enabled = self.overlap_checkbox.isChecked()
        overlap_size = self.block_size_input.value() // 50  # Например, 50% от block_size
        block_size = self.block_size_input.value()

        if not model_path or not dataset_path:
            self.log_text.append("Выберите модель и датасет перед началом обучения.")
            return

        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.log_text.clear()
        self.progress_bar.setValue(0)

        self.worker = TrainingWorker(model_path, dataset_path, 'cuda' if torch.cuda.is_available() else 'cpu',
                                     batch_size, epochs, gradient_accumulation_steps, overlap_enabled,
                                     overlap_size, block_size)
        self.worker.update_progress.connect(self.update_progress)
        self.worker.update_log.connect(self.update_log)
        self.worker.training_finished.connect(self.training_finished)
        self.worker.start()

    def stop_training(self):
        if self.worker is not None:
            self.worker.stop_training()
            self.worker.quit()

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_log(self, message):
        self.log_text.append(message)

    def training_finished(self):
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.log_text.append("Обучение завершено.")


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
